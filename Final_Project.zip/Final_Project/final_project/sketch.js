/*
-Final Game Project

Sound extension: My project has three different sounds; one every time the character jumps, the second when the character touches any collectable and the last sound when the character is falling from any of the canyons. 
The parts I found difficult: When I put the sound every time the character was falling into the canyons, it started sounding extremely different as the original sound and it wouldn’t stop after the game restarted. I understood that I had to change the rate of the sound and I needed to use the “stop()” function to end the sound once the character has died or lost a life. 
Skills: I learned how the functions of sound worked and which ones could help me improve my project by implementing them and by trying them on the code.

Platforms extension: I made four yellow platforms for this project using the factory pattern, the character can walk on top of any of them and they make the game more interesting. 
The parts I found difficult: Understanding the logic of the function “createPlatforms()” and its arguments was hard at first, it was extremely helpful to do it step by step with the video. The hardest part of the function was to understand how to check if the character had contact with the platform and that it was on top of the platform and not under. 
Skills: Testing the game every time I added another part of the function “createPlatforms()” helped me learn how extremely important is not to just add code without knowing exactly why are you adding it, if you don’t understand what your adding you won’t be able to correct or improve the code.


*/

var gameChar_x;
var gameChar_y;
var floorPos_y;
var scrollPos;
var gameChar_world_x;

var isLeft;
var isRight;
var isFalling;
var isPlummeting;

var trees_x;
var mountains;
var clouds;
var collectables;
var canyons;

var game_score;
var flagpole;
var lives;

var platforms;
var jumpSound;
var freeFall;
var coinCollect;

function preload()
{
    soundFormats('mp3','wav');
    
    //load your sounds here
    jumpSound = loadSound('assets/jump.wav');
    freeFall = loadSound('assets/fall.mp3');
    coinCollect = loadSound('assets/coin_collect.mp3');
    jumpSound.setVolume(0.1);
    freeFall.setVolume(0.02);
    freeFall.rate(0.7);
    coinCollect.setVolume(0.1);
}


function setup()
{
	createCanvas(1024, 576);
    floorPos_y = height * 3/4;
    lives = 3;
    startGame();

}

function startGame(){
    gameChar_y = floorPos_y;
	gameChar_x = width/2;

	// Variable to control the background scrolling.
	scrollPos = 0;

	// Variable to store the real position of the gameChar in the game
	// world. Needed for collision detection.
	gameChar_world_x = gameChar_x - scrollPos;

	// Boolean variables to control the movement of the game character.
	isLeft = false;
	isRight = false;
	isFalling = false;
	isPlummeting = false;

	// Initialise arrays of scenery objects.
    trees_x = [70, 250, 500, 1000, 1800];
    
    clouds = [{pos_x: 100, pos_y: 200},
             {pos_x: 600, pos_y: 100},
             {pos_x: 1400, pos_y: 200}];
    
    mountains = [{pos_x: 300, height: 400},
                {pos_x: 900, height: 400},
                {pos_x: 1600, height: 400}];
    
    collectables = [{x_pos: 110, y_pos: floorPos_y - 90, size: 40, isFound: false},
                    {x_pos: 850, y_pos: floorPos_y, size: 40, isFound: false},
                    {x_pos: 600, y_pos: floorPos_y, size: 40, isFound: false},
                    {x_pos: 1040, y_pos: floorPos_y - 100, size: 40, isFound: false},
                    {x_pos: 1200, y_pos: floorPos_y, size: 40, isFound: false},
                    {x_pos: 1400, y_pos: floorPos_y - 100, size: 40, isFound: false},
                    {x_pos: 2100, y_pos: floorPos_y, size: 40, isFound: false}];
    
    canyons = [{x_pos: 300, width: 200},
              {x_pos: 1000, width: 200},
              {x_pos: 1700, width: 200}];
    
    platforms = [];
    platforms.push(createPlatforms(90, 345, 150));
    platforms.push(createPlatforms(900, 340, 150));
    platforms.push(createPlatforms(1300, 340, 150));
    platforms.push(createPlatforms(2100, 340, 150));
    
    
    flagpole = {isReached: false, x_pos: 2300};
    game_score = 0;
}

function draw()
{
	background(100, 155, 255); // fill the sky blue

	noStroke();
	fill(0, 155, 0);
	rect(0, floorPos_y, width, height/4); // draw some green ground

    push()
    translate(scrollPos, 0);
	// Draw clouds.
    drawClouds();
	// Draw mountains.
    drawMountains();
	// Draw trees.
    drawTrees();
    
    //Draw platforms
    for(var i=0; i < platforms.length; i++)
    {
        platforms[i].draw();
    }
    
	// Draw canyons.
    for(var i=0; i < canyons.length; i++)
    {
        drawCanyon(canyons[i]);
        checkCanyon(canyons[i]);
        
    }
	// Draw collectable items.
    for(var i=0; i < collectables.length; i++)
    {
        if(collectables[i].isFound == false)
        {
            drawCollectable(collectables[i]);
            checkCollectable(collectables[i]);
        } 
    }
    
    renderFlagpole();
    checkPlayerDie();

    
    pop();

	// Draw game character.
	
	drawGameChar();
    
    //Draw Score
    fill(255, 165, 0);
    noStroke();
    textSize(32);
    textStyle(BOLD);
    text("Score: " + game_score, 50, 50);
    text("Lives:  " + lives, 50, 90);
    
    //Condition for Game over
    if(lives < 1)
    {
        fill(0);
        rect(220, 60, 610, 100);
        fill(255, 0, 0);
        textSize(32);
        textStyle(BOLD);
        noStroke();
        text("Game over! Press space to continue.", 250, 120);
        freeFall.stop();
        lives = 1;
        if(key == " " || key == "w")
        {
            lives = 3;
            startGame();
        }
    }
    //Condition for Winning the game
    if(flagpole.isReached == true)
    {
        fill(0);
        rect(220, 60, 650, 100);
        fill(255, 0, 0);
        textSize(32);
        textStyle(BOLD);
        noStroke();
        fill(255, 0, 0);
        noStroke();
        text("Level complete! Press space to continue.", 230, 120);
        if(key == " " || key == "w")
        {
            lives = 3;
            startGame();
        }
    }

	// Logic to make the game character move or the background scroll.
	if(isLeft)
	{
		if(gameChar_x > width * 0.2)
		{
			gameChar_x -= 5;
		}
		else
		{
			scrollPos += 5;
		}
	}

	if(isRight)
	{
		if(gameChar_x < width * 0.8)
		{
			gameChar_x  += 5;
		}
		else
		{
			scrollPos -= 5; // negative for moving against the background
		}
	}

	// Logic to make the game character rise and fall.
    if(gameChar_y < floorPos_y)
    {
        var isContact = false;
        for(var i = 0; i < platforms.length; i++)
        {
            if(platforms[i].checkContact(gameChar_world_x, gameChar_y) == true)
            {
                isContact = true;
                break;
            }
        }
        if(isContact == false)
        {
            gameChar_y += 2;
            isFalling = true; 
        }  
    }
    else
    {
        isFalling = false;
    }
    
    if(flagpole.isReached == false)
    {
        checkFlagpole();
    }
    
    

	// Update real position of gameChar for collision detection.
	gameChar_world_x = gameChar_x - scrollPos;
}


// ---------------------
// Key control functions
// ---------------------

function keyPressed()
{
    if(key == "A" || keyCode == 37)
    {
        isLeft = true;
    }
    if(key == "D" || keyCode == 39)
    {
        isRight = true;
    }
    if(key == " " || key == "w")
    {
        if(!isFalling){
            gameChar_y -=100;
            jumpSound.play();
        }
    }

}

function keyReleased()
{

	if(key == "A" || keyCode == 37)
    {
        isLeft = false;
    }
    if(key == "D" || keyCode == 39)
    {
        isRight = false;
    }

}
// ------------------------------
// Game character render function
// ------------------------------

// Function to draw the game character.

function drawGameChar()
{
	// draw game character
    if(isLeft && isFalling)
    {
        // add your jumping-left code
        fill(255,20,147);
        ellipse(gameChar_x, gameChar_y - 42, 60,50); //body
        fill(0);
        rect(gameChar_x - 12, gameChar_y -19, 10, 20);//left_leg
        rect(gameChar_x + 6, gameChar_y -23, 10, 20);//right_leg
        fill(255,0,0);
        triangle(gameChar_x - 30, gameChar_y - 60, gameChar_x + 2 , gameChar_y-85, gameChar_x+30, gameChar_y-60);//hat
        fill(255,255,255);
        ellipse(gameChar_x - 5, gameChar_y - 45, 30,25);//white_eye
        fill(0);
        ellipse(gameChar_x-10, gameChar_y - 45, 15,12);//black_eye
        stroke(0);
        strokeWeight(5);
        line(gameChar_x - 18, gameChar_y - 26, gameChar_x - 10, gameChar_y - 29); //mouth

	}
	else if(isRight && isFalling)
    {
		// add your jumping-right code
        fill(255,20,147);
        ellipse(gameChar_x, gameChar_y - 42, 60,50); //body
        fill(0);
        rect(gameChar_x - 12, gameChar_y -23, 10, 20);//left_leg
        rect(gameChar_x + 6, gameChar_y -19, 10, 20);//right_leg
        fill(255,0,0);
        triangle(gameChar_x - 30, gameChar_y - 60, gameChar_x + 2 , gameChar_y-85, gameChar_x+30, gameChar_y-60);//hat
        fill(255,255,255);
        ellipse(gameChar_x + 5, gameChar_y - 45, 30,25);//white_eye
        fill(0);
        ellipse(gameChar_x+10, gameChar_y - 45, 15,12);//black_eye
        stroke(0);
        strokeWeight(5);
        line(gameChar_x + 10, gameChar_y - 29, gameChar_x + 18, gameChar_y - 26); //mouth

	}
	else if(isLeft)
    {
		// add your walking left code
        fill(255,20,147);
        ellipse(gameChar_x, gameChar_y - 42, 60,50); //body
        fill(0);
        rect(gameChar_x - 12, gameChar_y -19, 10, 20);//left_leg
        rect(gameChar_x + 6, gameChar_y -19, 10, 20);//right_leg
        fill(255,0,0);
        triangle(gameChar_x - 30, gameChar_y - 60, gameChar_x + 2 , gameChar_y-85, gameChar_x+30, gameChar_y-60);//hat
        fill(255,255,255);
        ellipse(gameChar_x - 5, gameChar_y - 45, 30,25);//white_eye
        fill(0);
        ellipse(gameChar_x-10, gameChar_y - 45, 15,12);//black_eye
        stroke(0);
        strokeWeight(5);
        line(gameChar_x - 18, gameChar_y - 26, gameChar_x - 10, gameChar_y - 29); //mouth

	}
	else if(isRight)
    {
		// add your walking right code
        fill(255,20,147);
        ellipse(gameChar_x, gameChar_y - 42, 60,50); //body
        fill(0);
        rect(gameChar_x - 12, gameChar_y -19, 10, 20);//left_leg
        rect(gameChar_x + 6, gameChar_y -19, 10, 20);//right_leg
        fill(255,0,0);
        triangle(gameChar_x - 30, gameChar_y - 60, gameChar_x + 2 , gameChar_y-85, gameChar_x+30, gameChar_y-60);//hat
        fill(255,255,255);
        ellipse(gameChar_x + 5, gameChar_y - 45, 30,25);//white_eye
        fill(0);
        ellipse(gameChar_x+10, gameChar_y - 45, 15,12);//black_eye
        stroke(0);
        strokeWeight(5);
        line(gameChar_x + 10, gameChar_y - 29, gameChar_x + 18, gameChar_y - 26); //mouth

	}
	else if(isFalling || isPlummeting)
    {
		// add your jumping facing forwards code
        fill(255,20,147);
        ellipse(gameChar_x, gameChar_y - 42, 60,50); //body
        fill(0);
        rect(gameChar_x - 12, gameChar_y -23, 10, 20);//left_leg
        rect(gameChar_x + 6, gameChar_y -19, 10, 20);//right_leg
        fill(255,0,0);
        triangle(gameChar_x - 30, gameChar_y - 60, gameChar_x + 2 , gameChar_y-85, gameChar_x+30, gameChar_y-60);//hat
        fill(255,255,255);
        ellipse(gameChar_x + 2, gameChar_y - 45, 30,25);//white_eye
        fill(0);
        ellipse(gameChar_x + 2, gameChar_y - 45, 15,12);//black_eye
        stroke(0);
        strokeWeight(5);
        line(gameChar_x - 5, gameChar_y - 29, gameChar_x + 10, gameChar_y - 29); //mouth

	}
	else
    {
		// add your standing front facing code
        fill(255,20,147);
        ellipse(gameChar_x, gameChar_y - 42, 60,50); //body
        fill(0);
        rect(gameChar_x - 12, gameChar_y -19, 10, 20);//left_leg
        rect(gameChar_x + 6, gameChar_y -19, 10, 20);//right_leg
        fill(255,0,0);
        triangle(gameChar_x - 30, gameChar_y - 60, gameChar_x + 2 , gameChar_y-85, gameChar_x+30, gameChar_y-60);//hat
        fill(255,255,255);
        ellipse(gameChar_x + 2, gameChar_y - 45, 30,25);//white_eye
        fill(0);
        ellipse(gameChar_x + 2, gameChar_y - 45, 15,12);//black_eye
        stroke(0);
        strokeWeight(5);
        line(gameChar_x - 5, gameChar_y - 25, gameChar_x + 10, gameChar_y - 25); //mouth
	}
}

// ---------------------------
// Background render functions
// ---------------------------

// Function to draw cloud objects.
function drawClouds()
{
    for(var i=0; i < clouds.length; i++)
    {
        fill(255);
        ellipse(clouds[i].pos_x, clouds[i].pos_y, 25, 25);
        ellipse(clouds[i].pos_x + 25, clouds[i].pos_y, 35, 35);
        ellipse(clouds[i].pos_x + 55, clouds[i].pos_y, 50, 50);   
    }
}
// Function to draw mountains objects.
function drawMountains()
{
    for(var i=0; i < mountains.length; i++)
    {
        fill(255,255,255);
        triangle(mountains[i].pos_x - mountains[i].height/2, floorPos_y,
                mountains[i].pos_x, floorPos_y - mountains[i].height,
                mountains[i].pos_x + mountains[i].height/2, floorPos_y);
        fill(100);
        triangle(mountains[i].pos_x - mountains[i].height/3, floorPos_y,
                mountains[i].pos_x, floorPos_y - mountains[i].height,
                mountains[i].pos_x + mountains[i].height/2, floorPos_y);
        
    }
}

// Function to draw trees objects.
function drawTrees()
{
    for(var i=0; i < trees_x.length; i++)
    {
        fill(100,50,0);
        rect(75 + trees_x[i], -200/2 + floorPos_y,50,200/2);
        fill(0,100,0);
        triangle(trees_x[i] +25, -200/4 + floorPos_y,
                trees_x[i] +100, -200 + floorPos_y,
                trees_x[i] +175, -200/4 + floorPos_y);
        fill(255,0,0);
        ellipse(trees_x[i] + 70, floorPos_y - 100,20,20);
        ellipse(trees_x[i] + 110, floorPos_y - 140,20,20);
    }
}


// ---------------------------------
// Canyon render and check functions
// ---------------------------------

// Function to draw canyon objects.

function drawCanyon(t_canyon)
{
    fill(50,25,0);
    rect(t_canyon.x_pos, 432, t_canyon.width, 200);
    fill(135,206,250);
    rect(t_canyon.x_pos+50, 432, t_canyon.width/2, 200);
}

// Function to check character is over a canyon.

function checkCanyon(t_canyon)
{
    if(gameChar_world_x > t_canyon.x_pos && 
       gameChar_world_x < (t_canyon.width + t_canyon.x_pos) && 
       gameChar_y >= floorPos_y)
    {
        isPlummeting = true;
    }
    if(isPlummeting)
    {
        gameChar_y += 1;
    }
    if(floorPos_y +1 < gameChar_y)
    {
       freeFall.play();
    }
}

// ----------------------------------
// Collectable items render and check functions
// ----------------------------------

// Function to draw collectable objects.

function drawCollectable(t_collectable)
{
    fill(255,223,0);
    stroke(100);
    strokeWeight(1);
    ellipse(t_collectable.x_pos, t_collectable.y_pos -20, t_collectable.size, t_collectable.size);
    fill(255,99,71);
    ellipse(t_collectable.x_pos, t_collectable.y_pos -20, t_collectable.size/2, t_collectable.size/2);

}

// Function to check character has collected an item.

function checkCollectable(t_collectable)
{
    if(dist(gameChar_world_x, gameChar_y, t_collectable.x_pos, t_collectable.y_pos) < t_collectable.size)
    {
        t_collectable.isFound = true;
        game_score += 1;
        coinCollect.play();
    }
}

function renderFlagpole()
{
    push();
    strokeWeight(5);
    stroke(180);
    line(flagpole.x_pos, floorPos_y, flagpole.x_pos, floorPos_y - 250);
    fill(204,0,0);
    noStroke();
    
    if(flagpole.isReached)
    {
        triangle(flagpole.x_pos, floorPos_y - 170, flagpole.x_pos + 80, floorPos_y - 200, flagpole.x_pos, floorPos_y - 250);
    }
    else
    {
        triangle(flagpole.x_pos, floorPos_y, flagpole.x_pos + 80, floorPos_y - 25, flagpole.x_pos, floorPos_y - 50);
    }
    pop();
}

// function check flagpole
function checkFlagpole()
{
    var d = abs(gameChar_world_x - flagpole.x_pos);
    if(d < 15){
        flagpole.isReached = true;
    }
}

//function check player die
function checkPlayerDie()
{
    if(gameChar_y > 576)
    {
        lives -= 1;
        if(lives < 1)
        {
        }
        else
        {
            startGame();
        }
    }
}

//function create platforms
function createPlatforms(x, y, length)
{
    var p = {
        x: x,
        y: y,
        length: length,
        draw: function(){
            fill(247,255,0);
            triangle()
            rect(this.x, this.y, this.length, 20);
        },
        checkContact: function(gc_x, gc_y)
        {
            if(gc_x > this.x && gc_x < this.x + this.length)
            {
                var d = this.y - gc_y;
                if(d >= 0 && d < 5)
                {
                    return true;   
                }   
            }
            return false;
        }
    }
    return p;
    
}

